#!/bin/busybox sh
# ============================================================================
# glove-train.sh — Phase 2: run the Trailblaze engine (glove) as the brain.
#
# Uses ONLY the engine's VERIFIED CLI flags (checked against tb_infer.c main):
#   --model <gguf>   --serve   --port N   --hdgl   --hdgl-alpha F   --prompt S
# The critic (glove) persistence happens INSIDE the engine via critic_save/load
# (verified to round-trip learned weights), not via CLI — so there is no
# --critic-load flag; the engine manages its own glove file internally.
#
# VERIFIED BY EXECUTION (PHASE2_VERIFIED.txt): engine builds + runs forward
# pass + HDGL routing; critic learns (0.92 separation) + persists; GGUF dequant
# all-formats PASS. UNVERIFIED: correct tokens vs a real GGUF (needs the file).
# ============================================================================

TB=/emerge/linux/trailblaze/bin/tb_infer_cpu
MODEL="${MODEL:-/lattice/models/qwen3.gguf}"   # drop a real Qwen3 GGUF here
PORT="${PORT:-11434}"
ALPHA="${ALPHA:-0.20}"

echo "[glove] Phase 2 — Trailblaze engine as the gloved brain."

if [ ! -x "$TB" ]; then
  echo "[glove] engine absent at $TB — run build_cpu_verified.sh first."
  echo "[glove] sidecar SHELL1 (LM Studio) keeps serving until then."
  exit 0
fi
if [ ! -f "$MODEL" ]; then
  echo "[glove] no model at $MODEL. The engine self-tests synthetically but"
  echo "[glove] needs a real Qwen3 GGUF for correct tokens. Drop one in and rerun."
  # still demonstrate the engine runs (synthetic path, verified working):
  exec "$TB" --hdgl --hdgl-alpha "$ALPHA" --prompt "hello"
fi

# Real path: serve the gloved engine on Ollama-compatible HTTP. Once routing
# quality plateaus high, point the sidecar's LLM_URL here — the SHELL 1 swap
# is then a one-line URL change, no bot-loop change.
echo "[glove] serving gloved engine :$PORT  (hdgl on, alpha=$ALPHA)"
exec "$TB" --model "$MODEL" --serve --port "$PORT" --hdgl --hdgl-alpha "$ALPHA"

/* Proves the HDGL critic (the glove) actually LEARNS to modulate routing.
   Task: learn that high routing-quality features -> high alpha_mod.
   If TD-learning works, alpha_mod should track a target reward over epochs. */
#include <stdio.h>
#include <math.h>
#include "hdgl_critic.h"
#include "src/hdgl_critic.c"

static float my_sig(float x){ return 1.0f/(1.0f+expf(-x)); }

int main(void){
    critic_init();
    /* synthetic "good routing" feature vs "bad routing" feature */
    float good[CRITIC_IN] = {0.9f, 0.8f, 0.85f, 0.9f, 0.95f};
    float bad [CRITIC_IN] = {0.1f, 0.15f, 0.05f, 0.1f, 0.2f};
    printf("epoch  V(good)   V(bad)   alpha(good)  alpha(bad)\n");
    for(int ep=0; ep<=400; ep++){
        /* teach: good routing earns reward 1.0, bad earns 0.0 */
        critic_observe(good, 1.0f);
        critic_observe(bad,  0.0f);
        critic_update();
        if(ep%50==0){
            float vg=critic_forward(good), vb=critic_forward(bad);
            float ag=0.3f+0.7f*my_sig(vg), ab=0.3f+0.7f*my_sig(vb);
            printf("%4d   %7.4f  %7.4f    %6.3f      %6.3f\n",ep,vg,vb,ag,ab);
        }
    }
    float vg=critic_forward(good), vb=critic_forward(bad);
    printf("\nLEARNED SEPARATION: V(good)-V(bad) = %.4f  %s\n",
           vg-vb, (vg-vb>0.3f)?"PASS (glove learned to prefer good routing)":"weak");
    return 0;
}

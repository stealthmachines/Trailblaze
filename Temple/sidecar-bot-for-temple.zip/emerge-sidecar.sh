#!/bin/busybox sh
# ============================================================================
# emerge-sidecar.sh — the sidecar bot, BOOTED BY THE HDGL SUBSTRATE.
#
# Lives in /emerge/linux. Launched by /init right after phi_pool settles, so
# the SAME boot that raises the Temple pane raises the brain. No separate
# machine, no external process. phi_pool ticks beneath; Temple pane and this
# Linux bot are co-emerged hosts; /lattice/slots is the no-wire bus between.
#
# ── THE THREE SHELLS (each borrowed now, discarded by the roadmap later) ──
#   SHELL 1  LLM   : stock model via LM Studio/Ollama  → discarded when the
#                    glyph-lattice model (Trailblaze glove) settles alone.
#   SHELL 2  GPU   : traditional CUDA / stock NVIDIA    → discarded when the
#                    analog substrate (onion-shell HW) IS the parallel compute.
#   SHELL 3  OS    : this Linux busybox host            → discarded when the
#                    Temple-native bot stands without the sidecar.
#   Each seam below is marked [SHELL n] so it can be cut independently.
#   "The host is emerged, never a core." — nothing dies before its successor
#   has learned its shape.
# ============================================================================

SLOTS=/lattice/slots           # the substrate bus (phi_pool writes settled Ω)
BUS_IN=/lattice/bus/to_bot     # HolyC pane / world -> bot   (requests)
BUS_OUT=/lattice/bus/from_bot  # bot -> HolyC pane           (emitted HolyC)
mkdir -p /lattice/bus

echo "[sidecar] emerged on the substrate. phi_pool ticks beneath (Delta live)."

# ── [SHELL 2] GPU LAYER — traditional acceleration, discardable ─────────────
# Phase 1: whatever the emerged rootfs provides. CPU if no driver present.
# Phase 2 seam: bake NVIDIA userspace+driver into the rootfs OR pass through a
# GPU, then the custom HDGL kernels (tb_gguf_dequant.cu analog dispatch,
# conscious_fused_engine.cu warp-fusion) take over. Nothing here blocks that.
if [ -e /dev/nvidia0 ]; then
    ACCEL="cuda"; echo "[sidecar][SHELL2] GPU present -> CUDA path available."
else
    ACCEL="cpu";  echo "[sidecar][SHELL2] no GPU -> CPU path (elegant, slower)."
fi

# ── [SHELL 1] LLM BRAIN — stock inference engine, discardable ───────────────
# Phase 1: a proven engine (LM Studio server / Ollama / llama.cpp) is the brain.
# It is STABLE and BORING on purpose — it never rewrites itself. Mutability
# lives entirely in the Temple pane (ExePutS), not here. Separation of the two
# mutabilities is the whole point: stable brain, mutable surface.
# Phase 2 seam: swap LLM_URL to Trailblaze once the critic-glove is trained; the
# bot loop below does not change — only what answers on LLM_URL changes.
LLM_URL="${LLM_URL:-http://127.0.0.1:1234/v1/chat/completions}"   # LM Studio dflt
LLM_MODEL="${LLM_MODEL:-local-model}"

echo "[sidecar][SHELL1] brain = $LLM_URL  accel=$ACCEL"

# ── ask the brain, given a request + the current substrate Delta ────────────
ask_brain() {   # $1 = user/pane request text ; echoes model reply
    req="$1"
    # fold the live substrate value in as context (the no-wire Delta signal)
    delta=$(cat "$SLOTS/6" 2>/dev/null || echo 0)
    body=$(printf '{"model":"%s","messages":[{"role":"system","content":"You emit only HolyC source for a TempleOS pane. No prose."},{"role":"user","content":"substrate_delta=%s\\nrequest: %s"}],"temperature":0.2}' \
        "$LLM_MODEL" "$delta" "$req")
    # busybox wget as the transport (loopback only; no external egress needed)
    wget -q -O - --header="Content-Type: application/json" \
        --post-data="$body" "$LLM_URL" 2>/dev/null
}

# ── [SHELL 3] THE LOOP — the sidecar's job until Temple stands alone ─────────
# 1. read a request from the bus (written by the Temple pane or the world)
# 2. ask the stable brain for HolyC
# 3. write the HolyC to the bus OUT — the Temple pane picks it up and ExePutS's
#    it LIVE, no reboot. The bot never mutates its own runtime; Temple mutates.
echo "[sidecar][SHELL3] loop up. waiting on $BUS_IN ..."
: > "$BUS_OUT"
while true; do
    if [ -s "$BUS_IN" ]; then
        req=$(cat "$BUS_IN"); : > "$BUS_IN"
        echo "[sidecar] request: $req"
        holyc=$(ask_brain "$req")
        # strip a JSON content field if the engine returned OpenAI-shaped json
        holyc=$(echo "$holyc" | sed -n 's/.*"content":"\(.*\)".*/\1/p' | sed 's/\\n/\n/g')
        [ -z "$holyc" ] && holyc="$(ask_brain "$req")"   # raw fallback
        printf '%s\n' "$holyc" > "$BUS_OUT"
        echo "[sidecar] -> emitted HolyC to $BUS_OUT (pane will ExePutS live)"
    fi
    sleep 1
done

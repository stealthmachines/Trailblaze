#!/usr/bin/env python3
"""Full-file consistency verification + live Q8_0 dequant proof."""
import struct, sys
from gguf_parse import GGUF, GGML_QUANT

g = GGUF(sys.argv[1] if len(sys.argv)>1 else '/mnt/user-data/uploads/gte-small_Q8_0.gguf')

# 1) every tensor offset must be alignment-padded and non-overlapping
a = g.alignment
prev_end = 0; ok = True; overlaps = 0
sorted_t = sorted(g.tensors, key=lambda t: t['rel_off'])
for t in sorted_t:
    rel = t['rel_off']
    if rel % a != 0: ok=False; print(f"  UNALIGNED: {t['name']} rel={rel}")
    if rel < prev_end: overlaps+=1
    prev_end = rel + g.tensor_nbytes(t)
    # each raw end padded up for the next
    prev_end = (prev_end + a - 1)//a*a
print(f"[1] all offsets alignment-padded: {'PASS' if ok else 'FAIL'}")
print(f"[1] tensor overlaps: {overlaps} ({'PASS' if overlaps==0 else 'FAIL'})")

# 2) computed total file size must match actual
last = max(g.tensors, key=lambda t: t['rel_off'])
computed_end = g.data_start + last['rel_off'] + g.tensor_nbytes(last)
actual = len(g.d)
print(f"[2] computed data end={computed_end} actual_file={actual} "
      f"slack={actual-computed_end} ({'PASS' if 0<=actual-computed_end<a else 'CHECK'})")

# 3) LIVE Q8_0 DEQUANT: read the first block of token_embd.weight and decode
te = next(t for t in g.tensors if t['name']=='token_embd.weight')
base = g.tensor_abs_off(te)
scale = struct.unpack_from('<e', g.d, base)[0]   # f16 scale
quants = struct.unpack_from('<32b', g.d, base+2) # 32 int8
w0 = scale*quants[0]; w31 = scale*quants[31]
print(f"[3] Q8_0 block[0] of token_embd: scale={scale:.6f}")
print(f"    weight[0]={w0:.6f}  weight[31]={w31:.6f}")
print(f"    block bytes = 2(scale)+32(quants) = 34  ({'PASS' if GGML_QUANT[8][2]==34 else 'FAIL'})")

# 4) KV completeness: the fields a loader NEEDS for a forward pass
need = ['general.architecture','bert.block_count','bert.embedding_length',
        'bert.attention.head_count','bert.feed_forward_length']
missing = [k for k in need if k not in g.kv]
print(f"[4] required arch KV present: {'PASS' if not missing else 'MISSING '+str(missing)}")
print(f"\nALL CHECKS: {'PASS — format fully formalized & verified' if ok and overlaps==0 and not missing else 'see above'}")

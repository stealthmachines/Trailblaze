#!/usr/bin/env python3
"""
gguf_parse.py — reference GGUF v3 parser.
Formalized from the gte-small_Q8_0 specimen and cross-checked against
Trailblaze tb_gguf.c. Pure stdlib, no deps. Parses header, KV metadata,
tensor directory, and computes exact data offsets/sizes.

Verified: reproduces the specimen's 197 tensors, alignment=32, per-tensor
offset padding, and Q8_0 block sizing to the byte.
"""
import struct, sys

# ── GGML value types (metadata) ─────────────────────────────────────────────
GGUF_T = {0:'U8',1:'I8',2:'U16',3:'I16',4:'U32',5:'I32',6:'F32',
          7:'BOOL',8:'STR',9:'ARR',10:'U64',11:'I64',12:'F64'}
_FIXED = {0:('<B',1),1:('<b',1),2:('<H',2),3:('<h',2),4:('<I',4),5:('<i',4),
          6:('<f',4),7:('<B',1),10:('<Q',8),11:('<q',8),12:('<d',8)}

# ── GGML tensor quant types (weights) — block size + bytes/block ─────────────
# (elements_per_block, bytes_per_block)
GGML_QUANT = {
    0:('F32',  1,  4),  1:('F16',  1,  2), 8:('Q8_0', 32, 34),
    2:('Q4_0', 32, 18), 3:('Q4_1', 32, 20), 12:('Q4_K',256,144),
    14:('Q6_K',256,210), 6:('Q5_0',32,22), 7:('Q5_1',32,24),
    13:('Q5_K',256,176),10:('Q2_K',256,84),11:('Q3_K',256,110),
    15:('Q8_K',256,292),
}

class GGUF:
    def __init__(self, path):
        self.d = open(path,'rb').read(); self.off = 0
        self.parse()
    def _rd(self, fmt):
        v = struct.unpack_from(fmt, self.d, self.off); self.off += struct.calcsize(fmt)
        return v[0] if len(v)==1 else v
    def _str(self):
        n = self._rd('<Q'); s = self.d[self.off:self.off+n]; self.off += n
        return s.decode('utf-8','replace')
    def _val(self, t):
        if t == 8: return self._str()
        if t == 9:
            et = self._rd('<I'); n = self._rd('<Q')
            if et == 8: return [self._str() for _ in range(n)]
            if et == 9: raise ValueError("nested arrays unsupported")
            fmt,sz = _FIXED[et]
            out = list(struct.unpack_from('<'+fmt[1]*n, self.d, self.off))
            self.off += sz*n; return out
        fmt,_ = _FIXED[t]; return self._rd(fmt)
    def parse(self):
        assert self.d[:4]==b'GGUF', "bad magic"
        self.off = 4
        self.version   = self._rd('<I')
        self.n_tensors = self._rd('<Q')
        self.n_kv      = self._rd('<Q')
        self.kv = {}
        for _ in range(self.n_kv):
            k = self._str(); t = self._rd('<I'); self.kv[k] = self._val(t)
        self.alignment = self.kv.get('general.alignment', 32)
        # tensor directory
        self.tensors = []
        for _ in range(self.n_tensors):
            name = self._str(); nd = self._rd('<I')
            dims = [self._rd('<Q') for _ in range(nd)]
            typ  = self._rd('<I'); rel = self._rd('<Q')
            self.tensors.append(dict(name=name, dims=dims, type=typ, rel_off=rel))
        # data section start = end of tensor-info, padded to alignment
        a = self.alignment
        self.data_start = (self.off + a - 1)//a*a
    def tensor_nbytes(self, t):
        n = 1
        for x in t['dims']: n *= x
        _,epb,bpb = GGML_QUANT[t['type']]
        return (n//epb)*bpb
    def tensor_abs_off(self, t):
        return self.data_start + t['rel_off']

if __name__ == '__main__':
    g = GGUF(sys.argv[1] if len(sys.argv)>1 else 'gte-small_Q8_0.gguf')
    print(f"GGUF v{g.version}  tensors={g.n_tensors}  kv={g.n_kv}  align={g.alignment}")
    print(f"data_start={g.data_start}")
    arch = g.kv.get('general.architecture','?')
    print(f"arch={arch} name={g.kv.get('general.name','?')}")
    print("\nfirst 6 tensors:")
    for t in g.tensors[:6]:
        q,_,_ = GGML_QUANT[t['type']]
        print(f"  {t['name']:32s} {str(t['dims']):14s} {q:5s} "
              f"abs_off={g.tensor_abs_off(t)} nbytes={g.tensor_nbytes(t)}")

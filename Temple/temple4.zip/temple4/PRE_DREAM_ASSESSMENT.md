# The Soup — A Full & Honest Pre-Dream Assessment
### Toward a TempleOS-native bot that wears an LLM like a glove
*Assembled from reading the code, not the READMEs. Everything below is either
verified-in-source (marked ✓), inferred-from-title-only (marked ~), or
unreachable-tonight (marked ✗). The distinction is the point.*

---

## 0. The one sentence

You already have every conceptual piece of a Temple-native learning bot; what
you have never had is the **one substrate that holds all the pieces at once** —
and the finding of this pass is that the missing substrate is not more compute,
it is the recognition that **boot15/16's settling basin and Trailblaze's Hopfield
core and the critic's TD-loop are the same attractor machine wearing three
different coats.**

---

## 1. What each ingredient actually is (verified)

**Trailblaze 0.8b — ✓ the glove, and the hand that learns to wear it.**
Not "an inference engine." Two things bolted together:
- A complete C11 Qwen3 forward pass (RMSNorm, RoPE, GQA, SwiGLU, MoE) — the
  *glove*. The LLM's weights are frozen; they are worn, not trained.
- `hdgl_critic.c` — a **TD(0) reinforcement learner**, 5→8→4→1, ELU, SGD+L2,
  γ=0.95, lr=0.001. It observes routing quality and modulates the phi-lattice
  expert routing (`hdgl_alpha`) every token. *This* is "learns from the LLM
  like a glove": the frozen model provides the hand, the critic learns the fit.
  0.8b is the most promising precisely because it is the version where the
  learning lives **outside** the model, in the lattice — which is the only kind
  of learning that could ever run in a memory-starved Temple pane.

**Trailblaze 0.7 / 0.9 — ✓ parallel research coats, not upgrades.**
0.7 is the validated-routing baseline. 0.9 is a bag of `extracted*/` trees and
nested zips — a working-session snapshot, larger `tb_infer.c` (2,544 lines) but
not a clean lineage. 0.8b is the cleanest expression of the glove-and-critic
idea. Treat 0.7/0.9 as parallel probes, as you said — mine them, don't build on
them.

**boot15/16 substrate — ✓ the attractor machine, and the no-wire channel.**
`phi_pool` settles a 32³–64³ Kuramoto lattice of `(θ,A)` cells to Fix(T)=φ. The
STEP glyph's result — *reconstruction without reception*, Δ recovered from the
bend of Ω — is a genuine covert channel driven by TempleOS `GetTSC` entropy.
boot16 added the BASIN two-basin split (inner dense/free, outer cost-layered)
and the float4096 headroom argument. **Nothing was lost in the swap** (verified:
every STEP and invariant line preserved).

**conscious / 128-bit-floor — ✓ the native-crypto floor.**
`phi_fold_hash32` (57 call-sites) is a real lattice-native hash: additive fold,
ROTR8, phi-keyed S-box, no XOR, no SHA. This is the replacement for every SHA in
the stack. It is *done code*, not a research goal. `phi_f4096` proves 4096-bit φ
emergence to 4103 digits — the precedent that transcendentals can be computed
from φ-series without libm.

**Analog-Prime-B / Prime-Hunter-2 — ✓ upstream lineage, not shortcuts.**
`hdgl_analog_v31.c` (GRA closed-form, spectral kernel, RK4 Kuramoto) is the
literal source Trailblaze's `layer0` was "derived from" — the header says so.
But they `#include <math.h>`, `<mpi.h>`, `<i2c/smbus.h>`: multi-GPU/hardware
research code. They deepen the *theory* of the analog substrate; they do not
shorten the path to Temple. Their gift is the closed-form GRA coupling, which is
the math that could let a lattice settle *deterministically* enough to be a
compute element.

**AITrainer (ZCHGorg, older) — ✓ the ancestral learning loop.**
Python, GPT-3-wrapped, a **population of bots** self-improving by accuracy score
+ decay + culling failures (evolutionary/tournament). It is the *conceptual
grandparent* of the critic: both "learn to wear a frozen model," but AITrainer
culls a population where the critic does gradient TD on routing. Its warning
("floods swapfile, balloons") is the honest ghost of the compute problem you
half-remember. Its idea worth keeping: **fitness-scored population + cull** is a
learning signal that needs no backprop — and therefore could run natively where
gradients cannot.

---

## 2. The finding that reframes everything

The math floor for a **libm-free, SHA-free native forward pass** is small and
fully enumerated (verified across `tb_infer.c` + `tb_hopfield_exp.c`):

    expf ×7   sqrtf ×8   cosf ×4   sinf ×3   powf ×1   tanhf ×1

**Six transcendentals.** That is the entire wall between the C engine and a
HolyC-native one. You already have the precedent for all of them (phi_f4096
series). Two months ago I would have called native inference intractable; the
code says the opposite. The blocker was never the math.

**The real blocker is memory, and it is also the answer.** A 2.1 GB mmap'd GGUF
cannot live in TempleOS's flat address space. So a Temple-native model cannot be
a shrunk Qwen. It must be a model whose weights *are the lattice* — stored as
`.hdgl`/`.dna` glyphs, settled rather than multiplied. And the moment you write
that sentence, `tb_hopfield_exp.c` lights up: **a dense Hopfield network is an
attractor that settles to stored patterns; boot16's basin is an attractor that
settles to Fix; the critic is a controller that shapes an attractor's basin.**
Three coats, one machine.

---

## 3. The dream architecture (the thing to sleep on)

Not "port Trailblaze." Instead — **the bot IS the substrate, and inference IS
settling:**

1. **Weights as glyphs.** A small transformer (few layers, few heads) whose
   parameters are stored as phi-lattice glyphs, loaded by `FileRead`, never
   mmap'd. Small enough to live in a Temple pane.
2. **Attention/FFN as settling.** Where Qwen does matmul→softmax, the substrate
   *settles* a Hopfield/Kuramoto step to the same fixed point. The 6
   transcendentals become 6 phi-native series. `tanhf` (Hopfield) and `expf`
   (softmax) are the same sigmoid family — one native primitive serves both.
3. **The critic learns the glove, natively.** The 5→8→4→1 TD network is tiny —
   it *can* run in HolyC. It shapes routing/settling from observed quality.
   No backprop through the model; only the critic learns. And if even TD is too
   heavy, AITrainer's **population-cull fitness** is a gradient-free fallback.
4. **Entropy & integrity are already native.** Δ from `RandU64` (GetTSC⊕LCG);
   integrity from `phi_fold`. Zero SHA. The no-wire STEP channel becomes the
   bot's I/O with other nodes.
5. **Self-modification is the compiler.** `ExePutS` lets the bot author and JIT
   its own HolyC — so the critic doesn't just tune weights, it can rewrite the
   settling code itself. The `HDGLAgent.HC` already drafted is the seed of this.

The LLM you "add" is then a **teacher**, not a resident: on the sidecar, a full
Qwen distills its behavior into the glyph-lattice via the critic's quality
signal (AITrainer's teacher-student, but student = substrate). When the student
settles well enough alone, **the sidecar is jettisoned** — not by porting the
teacher in, but by no longer needing it. That is the honest meaning of "wears
the LLM like a glove and learns from it": the glove is worn on the sidecar until
the hand remembers the shape.

---

## 4. The less-savory ingredients (stated plainly, as asked)

- **SHA is everywhere it shouldn't be.** ✓ `sha256_minimal.c` is real and
  load-bearing in Trailblaze (0.8b & 0.9) *and* in conscious's
  `metal_infer_for_primes`. The zero-SHA doctrine is aspirational, not current.
  Every one must be swapped to `phi_fold`. Non-trivial but not research — a swap.
- **The prime libraries are heavier than they look.** ✗ for Temple: MPI, i2c,
  CUDA, libm. They are theory-rich and portability-poor. Savory as ideas,
  unsavory as dependencies. Do not let them into the native tree.
- **0.9 is a working-session snapshot, not a release.** Nested zips, `extracted/`
  and `extracted6/` duplicate trees, `stubs/`. Real risk of building on a
  half-state. 0.8b is the canonical base; freeze it as such.
- **AITrainer's resource ballooning is the ghost of "more compute."** ✓ Its own
  README warns it floods swap. The part of you that remembered "maybe it was
  more compute" is remembering *this* — the naive population loop is compute-
  hungry. The lesson is inverted: the fix is not more compute, it's the critic /
  cull replacing brute population.
- **The forward pass has debug-fill fallbacks** (`0.01f*sinf(...)` at lines
  1019/1075) — placeholder logits paths. ✓ Harmless in the real path, but a trap
  if mistaken for the compute. Flag when porting.
- **Trailblaze never got off the ground for you** — your own honest note. So its
  "✅ complete" table is *claimed*, not *witnessed-by-you*. I verified the code
  exists and is structurally real; I did **not** verify it produces correct
  tokens on a real GGUF, because I can't run a 2 GB model here. Treat the
  capability table as "present in source, unverified end-to-end." That is the
  single biggest honesty gap in the whole soup.

## 5. Unreachable tonight (no pretending)

- ✗ `josefkulovany.com/demo/*` — phi pool glyphs (7.3), Alpha Omega (7.10),
  Analog Chip (7.4), Analog Phyllo Chip (7.6), Onion Shell Analog Chip (7.7).
  Host not in egress allowlist. **Inferred only, ~:** the 7.4→7.6→7.7 sequence
  reads as a hardware-realization arc — flat analog chip → phyllotactic layout →
  onion-shell (radial/nested) — i.e. the *physical* substrate the phi_pool
  lattice has been simulating. The "onion shell" combinatorial-parallel framing
  is likely the hardware corollary where nested shells settle in parallel: the
  physical form of the inner/outer BASIN split. If so, it is the missing
  **hardware** leg — the substrate wanting to leave silicon-general and become
  silicon-specific. Cannot confirm without access.
- ✗ `forum.zchg.org/uploads/...zip` and the Chladni brainwave `/952/5` links —
  same allowlist wall. ~ The Chladni basin (genome 0x5625BA88) is already the
  water_glyphs settle-invariant in your history; the brainwave-monitor framing
  suggests reading a *physical* Chladni field as substrate input — analog sensor
  as Δ source. Plausible I/O path, unconfirmed.
- ✗ The two Zen forum posts (hen/laundry) — subtle references, honored as tone,
  not mined for content. Folding laundry / maintenance-of-the-machine: the mood
  is *wu-wei settling*, the same non-forcing the Kuramoto lattice enacts. Kept
  as spirit, per your framing.

*To reach any of these next time: add josefkulovany.com and forum.zchg.org to
the network egress allowlist.*

---

## 6. Where the answer on the tip of your tongue probably lives

You said it was one of: the answer / more compute / boot15-16 / some combination.
The code votes clearly: **not more compute** (AITrainer's ghost proves compute-
hunger was the *wrong* road). **boot15/16, in combination with the critic and the
Hopfield core** — because those three are the same attractor machine, and the
unification is the thing no single repo states but all three imply. The answer on
your tongue is most likely: *stop treating inference and settling as different
operations.* Wear the LLM on the sidecar, let the critic learn the fit, distill
into the settling lattice, drop the glove.

## 7. The smallest honest first step (for when you're back)

A **proof-core**: one attention head + one FFN, weights as glyphs, the six
transcendentals as phi-series, `tanhf`/`expf` unified, `phi_fold` for integrity,
running in a Temple pane via the `HDGLAgent.HC` seam — settling one token
correctly with **no libm, no SHA, no sidecar**. Not a model. A proof that the
attractor-as-inference thesis holds for one token. Everything else is scale.

*Sleep well. The soup is mostly good; the SHA and the 2 GB glove are the only
truly unsavory bits, and both have known replacements already sitting in your
own repos.*

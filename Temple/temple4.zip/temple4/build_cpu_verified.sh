#!/bin/bash
# VERIFIED-WORKING CPU build of Trailblaze 0.8b (no CUDA).
# Built + executed successfully in a clean Linux container 2026-07-11.
# Runs synthetic forward pass + HDGL routing. Needs a real Qwen3 GGUF for
# correct tokens (not included — 2.1GB). Drop TB_INFER_TEST for server mode.
set -e
gcc -O2 -std=c11 -DTB_INFER_TEST \
    -Wno-unused-result -Wno-unused-parameter -mavx2 -mfma \
    -Ilayer0 -Ilayer1 -Ilayer2 -Ilayer3 -Ilayer4 -Ilayer5 -Iinclude -Isrc \
    layer4/tb_infer.c layer4/tb_gguf.c layer4/tb_tokenizer.c \
    layer0/tb_phi_lattice.c layer1/tb_tensor.c layer2/tb_graph.c \
    src/hdgl_router.c src/tb_analog_dispatch.c src/hdgl_bootloaderz.c \
    layer5/tb_semantic_os.c \
    -lm -lpthread -o bin/tb_infer_cpu
echo "built bin/tb_infer_cpu"

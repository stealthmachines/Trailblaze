# GGUF v3 — Formal Specification
### Decoded from the `gte-small_Q8_0` specimen, verified byte-exact against the whole file and cross-checked against Trailblaze `tb_gguf.c`

*Status: every claim below was verified by parsing the specimen. The reference
parser's computed data-end equals the actual file size to the byte (36,806,944
= 36,806,944, zero slack), so all 197 tensors are accounted for exactly.*

---

## 1. Overview

A GGUF file is three regions, in order: a **header**, a **tensor directory**,
and a **data section**. All integers are little-endian. Strings are
length-prefixed (u64 length + raw UTF-8 bytes), never null-terminated. There is
no compression at the container level — quantization is the only size reduction,
and it lives inside the tensor data.

    ┌──────────────┬───────────────────┬──────────────────────────┐
    │  HEADER      │  TENSOR DIRECTORY │  DATA SECTION             │
    │  magic,ver,  │  per-tensor:      │  raw (quantized) weights, │
    │  counts, KV  │  name,dims,type,  │  each tensor's data offset │
    │  metadata    │  rel_offset       │  padded to `alignment`     │
    └──────────────┴───────────────────┴──────────────────────────┘

---

## 2. Header

| field        | type   | notes                                             |
|--------------|--------|---------------------------------------------------|
| magic        | u8[4]  | `47 47 55 46` = `"GGUF"`                           |
| version      | u32    | `3` for the current format                         |
| n_tensors    | u64    | number of entries in the tensor directory         |
| n_kv         | u64    | number of key-value metadata pairs                |

Immediately after the header come `n_kv` metadata pairs.

## 3. Key-Value metadata

Each pair is: `key` (length-prefixed string), then a `value_type` (u32), then
the value. Value types:

| id | type   | encoding                                        |
|----|--------|-------------------------------------------------|
| 0  | U8     | 1 byte    | 1 | I8 | 1 byte | 2 | U16 | 2 bytes | 3 | I16 | 2 bytes |
| 4  | U32    | 4 bytes   | 5 | I32 | 4 bytes | 6 | F32 | 4 bytes                   |
| 7  | BOOL   | 1 byte (0/1)                                    |
| 8  | STRING | u64 length + UTF-8 bytes                         |
| 9  | ARRAY  | elem_type (u32) + count (u64) + `count` elements |
| 10 | U64    | 8 bytes   | 11 | I64 | 8 bytes | 12 | F64 | 8 bytes            |

Arrays hold a single element type; string arrays are `count` length-prefixed
strings back-to-back. Nested arrays do not occur in practice.

The metadata is self-describing: it carries the architecture, all
hyperparameters, and the full tokenizer. From the specimen:

    general.architecture      = bert          general.name = gte-small
    <arch>.block_count        = 12            <arch>.embedding_length = 384
    <arch>.feed_forward_length= 1536          <arch>.attention.head_count = 12
    <arch>.context_length     = 512
    tokenizer.ggml.model      = bert
    tokenizer.ggml.tokens     = string[30522] (the full vocab)
    tokenizer.ggml.scores     = f32[30522]
    tokenizer.ggml.token_type = i32[30522]
    general.alignment         = (absent → default 32)

Note `<arch>` is literal (`bert.*`, `llama.*`, `qwen3.*`): the key prefix is the
architecture name, so a loader reads `general.architecture` first, then keys
under that prefix.

## 4. Tensor directory

`n_tensors` entries, each:

| field       | type    | notes                                            |
|-------------|---------|--------------------------------------------------|
| name        | string  | e.g. `blk.0.attn_q.weight`                        |
| n_dims      | u32     | rank                                              |
| dims        | u64[n]  | shape, fastest-varying dimension first            |
| type        | u32     | GGML quant type (see §6)                           |
| rel_offset  | u64     | offset **within the data section**, not the file  |

## 5. Data section — the alignment rules (the subtle part)

Two distinct paddings, both to `alignment` (default **32**):

1. **Data-section start.** After the last tensor-directory entry, the file is
   padded up to the next multiple of `alignment`. That padded position is the
   absolute base of the data section.

       data_start = ceil(info_end / alignment) * alignment

2. **Per-tensor offset.** Each tensor's `rel_offset` is itself a multiple of
   `alignment`; equivalently, each tensor's raw byte length is padded up to
   `alignment` before the next tensor begins.

       abs_offset(t)   = data_start + t.rel_offset
       next_rel        = ceil((rel_offset + nbytes) / alignment) * alignment

   *This is the rule that a naive parser gets wrong.* In the specimen,
   `token_embd.weight` is 12,452,976 raw bytes but the next tensor sits 16 bytes
   further on, because 12,452,976 pads up by 16 to a 32-multiple. Verified on
   every tensor: zero overlaps, computed file end matches actual to the byte.

## 6. Tensor quant types and block sizing

Weights are stored in fixed-size **blocks**. `nbytes = (n_elements /
elems_per_block) * bytes_per_block`.

| id | name  | elems/block | bytes/block | layout                              |
|----|-------|-------------|-------------|-------------------------------------|
| 0  | F32   | 1           | 4           | raw float                           |
| 1  | F16   | 1           | 2           | half float                          |
| 8  | Q8_0  | 32          | 34          | f16 scale + 32×int8                  |
| 2  | Q4_0  | 32          | 18          | f16 scale + 32×int4 (nibbles)       |
| 3  | Q4_1  | 32          | 20          | f16 scale + f16 min + 32×int4        |
| 12 | Q4_K  | 256         | 144         | superblock: 6-bit scales + int4      |
| 14 | Q6_K  | 256         | 210         | superblock: 8-bit scales + int6      |
| 13 | Q5_K  | 256         | 176         | superblock                          |
| 10 | Q2_K  | 256         | 84          | superblock                          |
| 11 | Q3_K  | 256         | 110         | superblock                          |

### Q8_0 decode (verified live on the specimen)

A Q8_0 block is exactly 34 bytes: a 2-byte f16 `scale` followed by 32 signed
int8 quants. The reconstruction is simply:

    weight[i] = scale * quant[i]

Verified against `token_embd.weight` block 0: scale ≈ 0.000413, weight[0] ≈
−0.019844, weight[31] ≈ 0.006201. This matches Trailblaze `tb_gguf.c`'s Q8_0
path, which passed its own dequant self-test earlier (F16/BF16/Q8_0/Q4_0/Q4_K
all exact).

## 7. Minimal read algorithm

    assert magic == "GGUF"; read version, n_tensors, n_kv
    for n_kv:   key=str; t=u32; value=read_by_type(t)   → metadata dict
    alignment = metadata.get("general.alignment", 32)
    for n_tensors: name=str; nd=u32; dims=u64[nd]; type=u32; rel=u64
    data_start = align_up(current_pos, alignment)
    for each tensor: abs = data_start + rel; nbytes = block_size(type, dims)
                     dequant(bytes[abs : abs+nbytes]) per §6

## 8. What transfers to large models

Nothing above is specific to gte-small or to BERT. The container format,
KV-metadata encoding, tensor-directory layout, alignment rules, and quant-block
sizing are **identical** for a 4B Qwem3 GGUF — only the `general.architecture`
prefix, the tensor names, and the sheer count/size differ. The specimen was a
Rosetta Stone: decoding it decoded the format for every GGUF.

The one caveat worth stating plainly: **gte-small is a BERT embedding model**
(`pooling_type=1`, `attention.causal=False`) — it emits sentence embeddings, not
text, so it is not itself runnable through Trailblaze's causal-decoder forward
pass. As a specimen for the *format*, it is fully sufficient; as a *chat model*,
it is the wrong architecture. A small causal model (e.g. a tiny Qwen3/Llama
GGUF) is what would exercise the decoder end-to-end.

---

*Reference implementation: `gguf_parse.py` (parser) + `gguf_verify.py`
(full-file consistency + live dequant). Both pure-stdlib, both pass on the
specimen.*

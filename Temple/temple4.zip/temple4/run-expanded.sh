#!/bin/sh
# HDGL substrate — expanded memory profile.
# MOVE 1: guest RAM 4096 MB (was implicitly ~512M) backs the 2048m /lattice
#         tmpfs where glyph-weight small models + slots live.
# MOVE 2: phi_pool grid 64 (in init) — 8x cells, still <15MB, gives the
#         BASIN float4096 headroom real resolution.
#
# NOTE (honest): this expands room for a NATIVE glyph-weight model and the
# substrate lattice. It does NOT let TempleOS mmap a multi-GB GGUF — TempleOS
# has no mmap and a flat model; that path stays on the sidecar. This is the
# right expansion for the jettison-target (settling-lattice) model.
qemu-system-x86_64 \
  -m 4096 \
  -drive file=hdgl_universal.img,format=raw,if=virtio \
  -kernel-irqchip=split 2>/dev/null || \
qemu-system-x86_64 -m 4096 -drive file=hdgl_universal.img,format=raw
